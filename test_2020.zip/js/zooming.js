 function zoomPlus(){
        document.getElementById("zoomin").classList.add("zoomer"); 
    }
          
    function zoomMinus()
    {
        document.getElementById("zoomin").classList.remove("zoomer"); 
    }