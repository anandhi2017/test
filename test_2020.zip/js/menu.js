// menu start
$(document).ready(function () {            
            $(window).resize(function () {
                if ($(window).width() >= 980) {

                    // when you hover a toggle show its dropdown menu
                    $(".navbar .dropdown-toggle").hover(function () {
                        $(this).parent().toggleClass("show");
                        $(this).parent().find(".dropdown-menu").toggleClass("show");
                    });

                    // hide the menu when the mouse leaves the dropdown
                    $(".navbar .dropdown-menu").mouseleave(function () {
                        $(this).removeClass("show");
                    });
                }
            });
        });
// menu end
// popup start
   function showModal() {
            document.getElementById("myDIV").style.display = "block";
            document.getElementById("myDIV").classList.add("show_btn_animation");
            document.getElementById("myDIV").classList.remove("close_btn_animation");
            document.getElementById("myDIV").style.opacity = 1;
        }
        function closeModal() {
            
            var e = document.getElementById("myDIV");
            // document.getElementById("myDIV").style.display = "none";
            var fadeEffect = setInterval(function () {
        if (!e.style.opacity) {
            e.style.opacity = 1;
            
        }
        if (e.style.opacity > 0) {
            e.style.opacity -= 0.1;
            if (e.style.opacity == 0) {
                e.style.display = "none";
                document.getElementById("myDIV").classList.add("close_btn_animation"); 
                e.style.opacity = 0;
            } 
        } else {
            clearInterval(fadeEffect);
        }
    }, 90);
          
        }
       // document.getElementById("myDIV").addEventListener('click', closeModal); 
// popup end